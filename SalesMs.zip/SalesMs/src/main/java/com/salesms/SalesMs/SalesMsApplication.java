package com.salesms.SalesMs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SalesMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SalesMsApplication.class, args);
	}

}
