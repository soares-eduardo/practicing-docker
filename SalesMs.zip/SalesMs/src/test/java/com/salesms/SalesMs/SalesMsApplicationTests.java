package com.salesms.SalesMs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SalesMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
